To draw The Map :
1- make sure the arduino serial is working 
2- find out which com the arduino is connected in "if you uses windows it will be com3 or defrent"
3- open ser.py to change the com to yours
4- change the nomber of mines discoverd
5- run the program and start print in serial from arduino 
6- the format of data comes from arduino must be :
x y type_of_mine
7- make sure that your data is not out of range in the last_map.py code if it is ... you must change the range from the code
8- Run last_map code 
9- if it's not working ... Call me :D 
10- make sure that you have pygame library 